import datetime
import json
import requests
import fake_useragent
from bs4 import BeautifulSoup

user = fake_useragent.UserAgent().random
header = {
    'user-agent': user
}

studies_time = {
    '1': '08:00-09:30',
    '2': '09:40-11:10',
    '3': '11:20-12:50',
    '4': '13:00-14:30',
    '5': '14:40-16:10',
    '6': '16:20-17:50',
    '7': '18:00-19:30',
    '8': '19:40-21:10'
}


def main():
    data = []
    today = datetime.date.today()
    # today = datetime.date.today() + datetime.timedelta(days=3)
    # print(today)
    link = f"https://www.kstu.ru/www_Ggrid.jsp?x=www_GFgrid&d={today}&f=320&g=41886#{today}"
    response = requests.get(link, headers=header).text
    soup = BeautifulSoup(response, 'lxml')
    # print(soup)
    block = soup.find('div', class_='col-12 d-none d-md-block mygrid').find_all('tr')
    try:
        for i, bl in enumerate(block):
            if i != 0 and (bl.find('td', bgcolor='#DBFDDF').text != "   "):
                data.append({
                    'studies_time': str(studies_time[f'{i}']),
                    'Name': bl.find('td', bgcolor='#DBFDDF').text
                })
        # print(data)
        with open('day_schedule.json', 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except AttributeError:
        data = []
        with open('day_schedule.json', 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)


if __name__ == '__main__':
    main()
